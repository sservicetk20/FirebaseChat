export const firebaseConfig = {
    apiKey: "AIzaSyBfSd3gdtrheWkO3Apz_h3rgdSKoiLF2WY",
    authDomain: "fir-chat-d4b96.firebaseapp.com",
    databaseURL: "https://fir-chat-d4b96.firebaseio.com",
    projectId: "fir-chat-d4b96",
    storageBucket: "fir-chat-d4b96.appspot.com",
    messagingSenderId: "264425426131"
  };
